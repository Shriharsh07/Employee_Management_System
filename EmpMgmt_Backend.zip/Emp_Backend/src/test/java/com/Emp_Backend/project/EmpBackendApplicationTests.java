package com.Emp_Backend.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

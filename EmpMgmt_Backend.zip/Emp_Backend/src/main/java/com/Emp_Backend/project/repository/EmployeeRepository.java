package com.Emp_Backend.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Emp_Backend.project.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> 
{

	
}

package com.Emp_Backend.project.service.Impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Emp_Backend.project.dto.EmployeeDto;
import com.Emp_Backend.project.entities.Employee;
import com.Emp_Backend.project.exception.ResourceNotFoundException;
import com.Emp_Backend.project.mapper.EmployeeMapper;
import com.Emp_Backend.project.repository.EmployeeRepository;
import com.Emp_Backend.project.service.EmployeeService;


@Service
public class EmployeeServiceImpl implements EmployeeService
{
	//Connecting to repository
	@Autowired
	private EmployeeRepository employeeRepository;
	
	//Creating an employee
	@Override
	public EmployeeDto createEmployee(EmployeeDto employeeDto) {
		Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
		Employee savedEmployee = employeeRepository.save(employee);	
		return EmployeeMapper.mapToEmployeeDto(savedEmployee);
	}
	
	//Get a single employee by providing the id
	@Override
	public EmployeeDto getEmployeeById(Long employeeId) {
		Employee employee = employeeRepository.findById(employeeId)
		.orElseThrow(()-> new ResourceNotFoundException("Employee does not exist with given id: "+employeeId ));
		return EmployeeMapper.mapToEmployeeDto(employee);
	}

	//Get all the employees
	@Override
	public List<EmployeeDto> getAllEmployees() {
		List<Employee> employees = employeeRepository.findAll();
		return employees.stream().map((employee)->EmployeeMapper.mapToEmployeeDto(employee))
				.collect(Collectors.toList());
	}

	//Updating the employee
	@Override
	public EmployeeDto updateEmployee(Long employeeId, EmployeeDto updatedEmployee) {
		//Throwing exception if id not found
		Employee employee = employeeRepository.findById(employeeId).orElseThrow(
				()->new ResourceNotFoundException("Employee Does not exist with given id: "+employeeId));
		
		//updating the employee object with new one
		employee.setFirstName(updatedEmployee.getFirstName());
		employee.setLastName(updatedEmployee.getLastName());
		employee.setEmail(updatedEmployee.getEmail());
		
		//saving the updated object
		Employee updatedEmployeeObj = employeeRepository.save(employee);
		
		return EmployeeMapper.mapToEmployeeDto(updatedEmployeeObj);
	}

	//Deleting the employee
	@Override
	public void deleteEmployee(Long employeeId) {
		
		//Throwing exception if id not found
		Employee employee = employeeRepository.findById(employeeId).orElseThrow(
				()->new ResourceNotFoundException("Employee Does not exist with given id: "+employeeId));
		
		//deleting using id
		employeeRepository.deleteById(employeeId);
		
	}

}
